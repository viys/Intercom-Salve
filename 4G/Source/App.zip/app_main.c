#include "app_main.h"
#include "KingPowerManage.h"
#include "uart.h"


// extern void AudioDuplexthread(void);
// extern void socket_thread(void);
// extern void file_thread(void);
// extern void AudioPlayMP3_init(void);
// extern void http_startTest(void);
//extern void At_Test(void);
extern void Uart_Test(void);
extern void Record_Test(void);
extern void Play_Test(void);
// extern int socket_thread(void);
// extern int file_thread(void);
// extern int AudioPlayMP3_init(void);
// extern int AudioDuplexthread();
// extern int http_startTest(void);
extern void Uart2_Init(void);
//extern void http_startTest(void);
extern void Audio_Test(void);

uint32 writeLen = 0;

void APP_Main(uint32 bootMode)
{

    Uart2_Init();

    DBG_U2_Send("Enter APP\r\n");

    POWER_REASON_E reason = bootMode;
    KING_SysLog("enter APP_Main... reason = %d", reason);
    
    KING_WakeLock(LOCK_SUSPEND, (uint8 *)"KingApp");

    // socket_thread();
    // file_thread();
    // AudioPlayMP3_init();
    // AudioDuplexthread();
    // http_startTest();
    
    KING_SysLog("enter APP_Main... reason =END");
//    Record_Test();
    
    //Play_Test();
    Audio_Test();
}
// reconnect