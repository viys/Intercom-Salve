#ifndef __APP_MAIN_H__
#define __APP_MAIN_H__

#include "KingDef.h"
#include "KingPlat.h"
#include "KingDef.h"
#include "KingCSTD.h"
#include "KingPlat.h"
#include "KingRtos.h"
#include "KingUart.h"
#include "app_main.h"

extern uint32 writeLen;
// void DBG_Uart_Send(char * ptr);
#define DBG_Uart_Send(a) {KING_UartWrite(UART_2, (uint8 *)a, sizeof(a)-1, &writeLen); KING_UartWrite(UART_2, (uint8 *)"\r\n", 2, &writeLen);}




#endif
