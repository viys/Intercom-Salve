#ifndef __UART_H
#define __UART_H

void DBG_U2_Send(char *format,...);


extern uint8 U2_TxBuff[1000];

#endif /* __UART_H */
